import {
  ArrowRight, AudioLines, BookOpen, FileText, MessageSquare,
  Sparkles, WandSparkles, ShieldCheck, Zap, Menu
} from "lucide-react";

const tools = [
  {
    number: "01",
    name: "AI Chat",
    description: "Think through ideas, get explanations and move from question to clarity.",
    label: "Your AI workspace",
    icon: MessageSquare,
    accent: "violet"
  },
  {
    number: "02",
    name: "English Practice",
    description: "Build confidence with guided conversations and helpful corrections.",
    label: "Speak with confidence",
    icon: AudioLines,
    accent: "pink"
  },
  {
    number: "03",
    name: "Resume Builder",
    description: "Turn your experience into a clear, professional resume.",
    label: "Make your next move",
    icon: FileText,
    accent: "blue"
  },
  {
    number: "04",
    name: "PDF Assistant",
    description: "Understand long documents with summaries and focused questions.",
    label: "Make documents simpler",
    icon: BookOpen,
    accent: "violet"
  }
];

export default function Home() {
  return (
    <main>
      <nav className="nav shell">
        <a className="brand" href="#" aria-label="Nuvara home">
          <span className="brand-mark"><Sparkles size={18} /></span>
          <span>nuvara</span>
        </a>
        <div className="nav-links">
          <a href="#tools">Explore tools</a>
          <a href="#about">Why Nuvara</a>
        </div>
        <a className="nav-cta" href="#tools">Explore Nuvara <ArrowRight size={15} /></a>
        <button className="mobile-menu" aria-label="Menu"><Menu size={20}/></button>
      </nav>

      <section className="hero shell">
        <div className="hero-copy">
          <div className="eyebrow"><span className="live-dot"/> YOUR SPACE TO THINK BIGGER</div>
          <h1>Make room for<br/><span>what’s possible.</span></h1>
          <p className="hero-sub">
            A thoughtful collection of AI tools to help you learn, create and get things done — all in one place.
          </p>
          <div className="hero-actions">
            <a className="primary-button" href="#tools">Explore the tools <ArrowRight size={17}/></a>
            <a className="quiet-link" href="#about">Discover Nuvara</a>
          </div>
          <div className="trust-line"><ShieldCheck size={15}/> Built to make everyday work feel simpler.</div>
        </div>

        <div className="hero-art" aria-label="Abstract purple glowing orb illustration">
          <div className="orbit orbit-one"/>
          <div className="orbit orbit-two"/>
          <div className="orb">
            <div className="orb-core"/>
            <Sparkles className="orb-spark" size={30}/>
          </div>
          <div className="float-card float-top"><span className="mini-icon"><WandSparkles size={15}/></span><span><b>Ideas, meet action.</b><small>Your creative space</small></span></div>
          <div className="float-card float-bottom"><span className="mini-icon blue"><Zap size={15}/></span><span><b>One simple workspace</b><small>Four tools to get started</small></span></div>
          <div className="art-caption">INTELLIGENCE, MADE USEFUL</div>
        </div>
      </section>

      <section className="tools-section shell" id="tools">
        <div className="section-heading">
          <div>
            <div className="eyebrow">THE NUVARA TOOLKIT</div>
            <h2>Good ideas deserve<br/><span>great tools.</span></h2>
          </div>
          <p>Start with what you need. Find a little more room to do your best work.</p>
        </div>
        <div className="tool-grid">
          {tools.map((tool) => {
            const Icon = tool.icon;
            return (
              <article className="tool-card" key={tool.number}>
                <div className="card-top"><span className={`tool-icon ${tool.accent}`}><Icon size={20}/></span><span className="tool-number">{tool.number}</span></div>
                <div className="tool-label">{tool.label}</div>
                <h3>{tool.name}</h3>
                <p>{tool.description}</p>
                <a className="card-link" href="mailto:hello@nuvara.com?subject=Nuvara%20early%20access">Coming soon <ArrowRight size={15}/></a>
              </article>
            );
          })}
        </div>
      </section>

      <section className="manifesto shell" id="about">
        <div className="manifesto-icon"><Sparkles size={22}/></div>
        <div>
          <div className="eyebrow">A MORE FOCUSED WAY FORWARD</div>
          <h2>Less switching.<br/><span>More creating.</span></h2>
          <p>Nuvara brings useful AI experiences together in a calm, simple workspace. We’re building carefully, starting with the tools people need most.</p>
        </div>
      </section>

      <footer className="footer shell">
        <a className="brand" href="#"><span className="brand-mark"><Sparkles size={16}/></span><span>nuvara</span></a>
        <span>Thoughtfully building what’s next.</span>
        <span>© {new Date().getFullYear()} Nuvara</span>
      </footer>
    </main>
  );
}
