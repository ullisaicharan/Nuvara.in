import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Nuvara — One workspace. More possibilities.",
  description: "A calmer workspace for thinking, learning and creating with AI."
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
